# -*- coding: utf-8 -*-
"""

    Copyright (C) 2011-2018 PleXBMC (plugin.video.plexbmc) by hippojay (Dave Hawes-Johnson)
    Copyright (C) 2018-2019 Composite (plugin.video.composite_for_plex)

    This file is part of Composite (plugin.video.composite_for_plex)

    SPDX-License-Identifier: GPL-2.0-or-later
    See LICENSES/GPL-2.0-or-later.txt for more information.
"""

from kodi_six import xbmc  # pylint: disable=import-error
from kodi_six import xbmcgui  # pylint: disable=import-error

from ..addon.strings import i18n
from ..plex import plex


def run():
    plex_network = plex.Plex(load=False)

    can_signout = True
    if not plex_network.is_admin():
        can_signout = False
        _ = xbmcgui.Dialog().ok(i18n('Sign Out'),
                                i18n('To sign out you must be logged in as an admin user. '
                                     'Switch user and try again'))
    if can_signout:
        result = xbmcgui.Dialog().yesno(i18n('myPlex'),
                                        i18n('You are currently signed into myPlex.'
                                             ' Are you sure you want to sign out?'))
        if result:
            plex_network.signout()
            xbmc.executebuiltin('Container.Refresh')
